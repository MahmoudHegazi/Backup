<?php include 'includes/header.php'; ?>

<divs>
<div id="wrapper">

	<!-- Navigation -->
	<?php include 'includes/navigation.php'; ?>


	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

					<h1 class="page-header">
						Welcome to the Administration Panel 						
					</h1>

				   <?php 
				   
				       if ((isset($_GET['name']))) {
					   $post_name = $_GET['name'];					   					  
					   $name = htmlentities($post_name);
					   add_pmessage($name);
					 
					 
					 
					   echo '<div class="alert alert-success alert-dismissible">';
					   echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
                       echo ' <strong>Success!</strong>' . add_pmessage($name);
                       echo ' </div>';
					   }
                     ?>
					  
					<?php
						if (isset($_GET['source'])) {
								$source = $_GET['source'];

						switch ($source) {
							case 'add_new':
								include "includes/add_post.php";
								break;
							default:
								include "includes/view_post.php";
								break;
						}
		}
					 ?>
</div>
				</div>
					 
					 


			</div>

			<!-- /.row -->

		</div>
		<!-- /.container-fluid -->

	</div>
	<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

</div>

<!-- jQuery -->
<script src="bootstrap/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
